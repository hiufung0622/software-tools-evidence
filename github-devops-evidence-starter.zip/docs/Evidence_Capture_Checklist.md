# Evidence Capture Checklist

Use this checklist to collect proof for your Professional Learning Report.

## Git & GitHub Basics
- [ ] Screenshot: GitHub **repository home** page (repo name visible)
- [ ] Screenshot: **Commit history** showing meaningful messages
- [ ] Screenshot: **Branches** page with `main` and at least one `feature/*` branch
- [ ] Screenshot: **Pull Request** with description (use `Closes #1`), reviewer, and merge

## Branching, Merging, Conflicts
- [ ] Screenshot: Conflict view in GitHub or VS Code (conflict markers shown)
- [ ] Screenshot: Resolved merge with final file diff
- [ ] Terminal snippet (copy/paste): commands used (`git checkout -b`, `git merge`, `git rebase`)

## Revert / Amend / Reset
- [ ] Screenshot: Terminal showing `git revert <hash>` and resulting commit
- [ ] Screenshot: Terminal showing `git commit --amend` edit
- [ ] Screenshot: Terminal showing `git reset --soft` or `--hard` (on a safe test branch)

## GitHub Actions (CI/CD)
- [ ] Screenshot: **Actions** tab showing a successful run of **CI Workflow**
- [ ] Screenshot: Run logs for steps: *Update index.html*, *Run custom vowel analyzer*, *Commit changes*
- [ ] Screenshot: README with an **Automated Update** block appended by the action
- [ ] Copy of YAML: `.github/workflows/ci.yml` in the report appendix

## Custom Action & Scripts
- [ ] Screenshot: Repo tree showing `.github/actions/vowel-frequency-analyzer/action.yml`
- [ ] Snippet: `frequency.py` output line “Vowel counts: {'a':..., 'e':...}”
- [ ] Screenshot: `update_readme.sh` change reflected in README

## Docker (optional but strong evidence)
- [ ] Screenshot: Dockerfile in repo
- [ ] Screenshot: Actions job step **docker build** (if you add Docker build to CI)
- [ ] Screenshot: Running container locally (`docker run -p 5000:5000 ...`) with browser `http://localhost:5000`

## GitHub Projects
- [ ] Screenshot: Project **board** with columns *To Do*, *In Progress*, *Done*
- [ ] Screenshot: Issue card moving across columns (manual or automated)
- [ ] Screenshot: Workflow that labels/marks stale issues (optional)
- [ ] Screenshot: Automation that moves issue to **Done** on PR merge (optional)

## IDE / Codespaces
- [ ] Screenshot: VS Code with the repo open (or GitHub Codespaces running)
- [ ] Screenshot: Terminal in VS Code running `git log --oneline`

## Quizzes
- [ ] Screenshot: Completion page(s) for the two short quizzes

---

**Tip:** Save all screenshots into a single PDF: `SoftwareTools_Evidence.pdf` and reference figure numbers in your report.
Generated: 2025-11-02 14:45:38 UTC

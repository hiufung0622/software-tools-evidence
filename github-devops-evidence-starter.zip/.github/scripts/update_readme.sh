#!/usr/bin/env bash
set -euo pipefail
FREQ_RESULT="${1:-}"
GITHUB_USER="${2:-unknown}"
TIMESTAMP="$(date -u +"%Y-%m-%d %H:%M:%S UTC")"

# Ensure README exists
touch README.md

{
  echo ""
  echo "## Automated Update"
  echo "- Actor: ${GITHUB_USER}"
  echo "- Time: ${TIMESTAMP}"
  echo "- ${FREQ_RESULT}"
} >> README.md

import sys
from collections import Counter

def count_vowels(text):
    vowels = 'aeiou'
    c = Counter(ch for ch in text.lower() if ch in vowels)
    return {v: c.get(v, 0) for v in vowels}

def main():
    if len(sys.argv) != 2:
        print("Usage: frequency.py <file>", file=sys.stderr)
        sys.exit(1)
    path = sys.argv[1]
    with open(path, 'r', encoding='utf-8') as f:
        data = f.read()
    counts = count_vowels(data)
    print("Vowel counts:", counts)

if __name__ == "__main__":
    main()
